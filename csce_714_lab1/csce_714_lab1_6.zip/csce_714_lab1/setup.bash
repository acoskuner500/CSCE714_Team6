#!/bin/bash
export UVMHOME="/opt/coe/cadence/XCELIUM/tools/methodology/UVM/CDNS-1.1d/sv"
source /opt/coe/cadence/XCELIUM/setup.XCELIUM.linux.bash
source /opt/coe/cadence/vmanager/setup.vmanager.linux.bash
echo Success
