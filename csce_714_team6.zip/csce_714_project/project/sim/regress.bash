#!/bin/bash
#add passing test cases here
declare -a arr=(
"base_test"
"read_hit_dcache"
"read_hit_icache"
"read_hit_lv2"
"read_miss_dcache"
"read_miss_icache"
"read_miss_with_replacement_dcache"
"read_miss_with_replacement_icache"
"read_miss_with_replacement_lv2"
"write_hit_dcache_ex"
"write_hit_dcache_mo"
"write_hit_dcache_sh"
"write_miss_dcache_cp_in_cache"
"write_miss_dcache"
"write_miss_with_replacement_dcache_cp_in_cache_ex"
"write_miss_with_replacement_dcache_cp_in_cache_mo"
"write_miss_with_replacement_dcache_cp_in_cache_sh"
"write_miss_with_replacement_dcache.sv"
"random_read"
"random_read_then_write"
"random_requests"
"random_write"
"random_write_then_read"
"random_read_address_target"
"random_request_target_address"
"random_write_address_target"
"ex_to_shared_ex_to_invalid"
"illegal_write"
"write_hit_dcache_shared_state"
"lv2_write_test"
"invalid_to_shared_fsm_test"
"fsm_exclusive_to_x"
"lv2_replacement"
"lv2_replacement_write"
"read_hit_lv1_dcache"
"read_hit_lv2_cpu1_followed_by_cpu0"
"read_miss_after_invalid_replacement"
"read_miss_cp_in_cache_modified"
"shared_to_invalid_fsm_test"
"write_hit_dcache_shared_state"
"write_hit_lv2"
"write_miss_with_replacement_lv2"
"write_miss_replacement_shared"
"invalidate_shared_fsm_test"
"random_core_random_requests_same_address"
"read_hit_lv1_icache"
        
        )
#number of times to run each test case
if [[ $# -eq 0 ]]; then
    LIMIT=1
else
    LIMIT=$1
fi


if [! -d logs]; then
    mkdir logs
fi
source ../../setup.bash
./CLEAR_LOGS
./CLEAR
irun -f cmd_line_comp_elab.f

for i in "${arr[@]}"
do
    for ((j=1; j<= LIMIT; j++))
    do
        irun -f sim_cmd_line.f +UVM_TESTNAME=$i -covtest "$i"_"$j" -svseed random
        cp xrun.log irun.log
        mv irun.log logs/"$i"_"$j".log
    done
done
./CLEAR
